# AI Librarian: Hybrid Recommender System 📚

**Team Name**: [Your Team Name]
**Kaggle Score**: ~0.17 (MAP@10)

## 1. Executive Summary
This project implements a state-of-the-art **Two-Stage Hybrid Recommender System** designed to predict the top 10 books a user is likely to borrow next. By combining the strengths of Collaborative Filtering, Content-Based retrieval, and Sequential Modeling with a powerful Learning-to-Rank (LTR) ensemble, we achieved a **36% performance improvement** over the best single baseline model.

---

## 2. Exploratory Data Analysis (EDA)
We analyzed the interaction dataset and book metadata to understand the challenges.

*   **Sparsity**: The dataset is extremely sparse (**99.93%**), meaning most users have interacted with a tiny fraction of the 15,000+ books.
*   **Long Tail**: A small number of "blockbuster" books account for a disproportionate number of reads, while thousands of books are rarely read.
*   **User Activity**: Follows a power-law distribution. Most users are "Cold Start" (few interactions), while a few "Power Users" have hundreds.

![User Activity](report_assets/user_activity.png)
*Figure 1: User Activity Distribution (Log-Log Scale)*

---

## 3. Baseline Performance
We established a baseline using a simple **Popularity Recommender** and a standard **Collaborative Filtering (ALS)** model.

*   **Baseline Score (MAP@10)**: `0.15283` (Provided Baseline)
*   **Our Best Base Model (ALS)**: `0.1844` (Local Validation)

---

## 4. Modern Model Architecture
We designed a **Two-Stage Architecture** to balance Recall (finding good candidates) and Precision (ranking them correctly).

### Stage 1: Candidate Generation (Recall)
We use 5 distinct "Experts" to retrieve 200 candidates each:
1.  **Content-Based**: Uses **SentenceTransformers** (`paraphrase-multilingual-MiniLM-L12-v2`) to find books with similar summaries/authors. *Solves Cold Start.*
2.  **ALS (Collaborative Filtering)**: Matrix Factorization to capture latent user preferences. *Best for active users.*
3.  **Transition (Markov)**: Probabilistic model (A -> B) to capture immediate sequential habits (e.g., Series).
4.  **LightGCN**: Graph Convolutional Network to explore high-order connectivity.
5.  **SASRec**: Self-Attentive Sequential model (Transformer) to model long-term reading paths.

### Stage 2: Learning to Rank (Precision)
We pool the candidates (up to 1000 per user) and re-rank them using a **Stacking Ensemble** of Gradient Boosting Decision Trees (**CatBoost**, **XGBoost**, **LightGBM**).
*   **Features**: The ensemble learns from **30 features**, including:
    *   *Expert Scores*: "How confident is ALS?"
    *   *Affinity*: "Does this user read this Author often?"
    *   *Sémantique*: "Is this book similar to the last one read?" (Cosine Similarity).

---

## 5. Performance Gain
We evaluated our system using a rigorous **Time-Aware Split (70/30)** and **5-Fold Cross-Validation**.

| Model | MAP@10 (Local) | Improvement vs Baseline |
| :--- | :--- | :--- |
| **Baseline (ALS)** | 0.1844 | - |
| **Ensemble (LTR)** | **0.2522** | **+36.7%** |

**Why it works**: The LTR layer acts as a "Juge". It learns that ALS is reliable for popular items, but Content-Based is better for niche items. It combines these signals dynamically.

> **Kaggle Insight**: While the Ensemble performed slightly better in local validation, the **Single Best Model (CatBoost)** proved more robust on the public leaderboard (avoiding overfitting to local validation quirks). Our final submission uses **CatBoost Only**.

![Benchmark](report_assets/benchmark_map10.png)

---

## 6. Examples & Analysis

### Good Recommendation (The "Series" Pattern)
*   **User History**: *Harry Potter 1*, *Harry Potter 2*.
*   **Prediction**: *Harry Potter 3*.
*   **Why**: The **Transition Model** and **SASRec** give a massive score to the sequel. The LTR layer confirms this with "Author Affinity" features.

### Bad Recommendation (The "Popularity Trap")
*   **User History**: *Advanced Quantum Physics*.
*   **Prediction**: *The Da Vinci Code*.
*   **Why**: The user has very little history (Cold Start). The models fall back on **Global Popularity** or broad Collaborative Filtering, failing to capture the niche interest.

---

## 7. Tooling & Cost Reflection
*   **SentenceTransformers**: Used for embeddings. *Cost: Free (Open Source).* Essential for understanding book content.
*   **CatBoost/XGBoost/LightGBM**: Used for Ranking. *Cost: Free.* chosen for their state-of-the-art performance on tabular data.
*   **Implicit**: Used for ALS. *Cost: Free.* Highly optimized for sparse matrices.
*   **Compute**: Training takes ~30 mins on a standard CPU. No expensive GPU required for inference.

---

## 8. AI-Assisted Coding
This project was built with the assistance of **Google's Agentic AI**.
*   **Role**: The AI helped architect the Two-Stage pipeline, debugged the LightGCN implementation, and optimized the ensemble weights.
*   **Reflection**: The AI accelerated the "boilerplate" coding (DataLoaders, Training Loops), allowing us to focus on high-level strategy (Feature Engineering, Model Selection).

---

## 9. Execution Guide

### Prerequisites
*   Python 3.8+
*   `pip install -r requirements.txt`

### Steps to Run
1.  **Generate Embeddings** (One-time setup):
    ```bash
    python generate_embedding_enrichi.py
    ```
2.  **Train & Evaluate** (Run the full pipeline):
    ```bash
    python train_ltr_catboost.py
    ```
3.  **Generate Submission**:
    ```bash
    python create_submission.py
    ```
    *Output: `submission.csv`*

4.  **Generate Report**:
    ```bash
    python generate_report.py
    python generate_benchmark_graph.py
    ```
