# AI Librarian Recommender System - System Documentation

## 1. Overview
This project implements a sophisticated Hybrid Recommender System designed to predict the top 10 books a user is likely to borrow next. The system leverages a two-stage approach:
1.  **Candidate Generation (Recall)**: A diverse ensemble of 5 base models generates a pool of high-quality candidates.
2.  **Learning to Rank (LTR)**: A stacking ensemble of Gradient Boosting Decision Trees (CatBoost, XGBoost, LightGBM) re-ranks these candidates to optimize the MAP@10 metric.

## 2. Data Loading & Preprocessing
-   **Interactions**: Loaded from `interactions_train.csv`.
-   **Items**: Enriched book metadata (Title, Author, Subjects, Summary, Publisher, Year) from `books_enriched_FINAL.csv`.
-   **Embeddings**: Pre-computed SentenceTransformer embeddings (`paraphrase-multilingual-MiniLM-L12-v2`) stored in `item_embeddings.pkl`.

## 3. Split Strategy
To prevent data leakage and simulate a realistic production scenario, we use a **Time-Aware User Split**:
-   **Method**: `user_time`
-   **Logic**: For each user, interactions are sorted chronologically.
-   **Base Train Split**: The first **70%** of each user's interactions are used to train the Base Models (Candidate Generators).
-   **LTR Train Split**: The remaining **30%** of interactions are used to train the LTR Layer. This ensures the LTR models learn to rank items that the base models *would have recommended* for the future, rather than memorizing past interactions.
-   **Validation**: Within the LTR phase, a 5-Fold Cross-Validation is performed on the users to ensure robustness.

## 4. Model Architecture

### Stage 1: Candidate Generation (Base Models)
We employ 5 distinct models to capture different signals (collaborative, content, sequence).

1.  **Content-Based Filtering**
    *   **Logic**: Builds user profiles by averaging embeddings of read books, weighted by time decay.
    *   **Hyperparameters**: `decay_days=180` (recent interactions matter more).
    *   **Similarity**: Cosine similarity between User Profile and Item Embeddings.

2.  **Collaborative Filtering (ALS)**
    *   **Library**: `implicit`
    *   **Algorithm**: Alternating Least Squares (Matrix Factorization).
    *   **Hyperparameters**:
        *   `factors=256`: Latent dimension size.
        *   `regularization=0.01`: To prevent overfitting.
        *   `iterations=20`: Training epochs.
        *   `alpha=80`: Confidence scaling for implicit feedback.

3.  **Transition Model (Markov Chain)**
    *   **Logic**: Calculates the probability of moving from Item A to Item B based on sequential patterns in user history.
    *   **Use Case**: Captures immediate sequential dependencies (e.g., reading Vol. 1 -> Vol. 2).

4.  **LightGCN (Graph Convolutional Network)**
    *   **Logic**: Propagates embeddings on the User-Item bipartite graph to capture high-order connectivity.
    *   **Hyperparameters**:
        *   `embedding_dim=256`
        *   `n_layers=3`: Number of graph convolution layers.
        *   `reg_weight=1e-4`
        *   `lr=0.0032`

5.  **SASRec (Self-Attentive Sequential Recommender)**
    *   **Logic**: Uses a Transformer architecture to model long-term sequential dependencies.
    *   **Hyperparameters**:
        *   `hidden_units=128`
        *   `num_blocks=2`: Transformer blocks.
        *   `num_heads=4`: Attention heads.
        *   `dropout_rate=0.43`
        *   `maxlen=100`: Sequence length.

### Stage 2: Learning to Rank (Ensemble)
The top 200 candidates from each base model are pooled and featurized. A stacking ensemble then re-ranks them.

#### Models
-   **CatBoostRanker**: Loss=`YetiRank`, Depth=6, Iterations=1000.
-   **XGBoostRanker**: Objective=`rank:ndcg`, Depth=6, Estimators=100.
-   **LGBMRanker**: Objective=`lambdarank`, Leaves=31, Estimators=100.

#### Features (30 Total)
The LTR models use a rich set of features for each (User, Item) pair:

**A. Score & Rank Features (From Base Models)**
-   Raw Scores from Content, CF, Transition, LightGCN, SASRec.
-   Ranks (1-200) from each model.
-   **Vote Count**: How many models proposed this item.
-   **Score Aggregates**: Mean, Std, Min, Max of normalized scores.

**B. Static Item Features**
-   Item Popularity (Global).
-   Author Popularity.
-   Publication Year.
-   Page Count.

**C. User Affinity Features**
-   **Author Affinity**: How many times user read this author.
-   **Subject Affinity**: Weighted sum of user's history with this item's subjects.
-   **Publisher Affinity**: How many times user read this publisher.

**D. Semantic Features**
-   **User-Item Similarity**: Cosine similarity between User Centroid and Item Embedding.
-   **Last-Item Similarity**: Cosine similarity between Last Read Book and Candidate Item.

**E. Advanced/Contextual Features**
-   **Author Ratio**: `Author Count / Total User Reads`.
-   **Subject Match Ratio**: % of item's subjects that user has interacted with.
-   **Time Delta**: Difference in years between Last Read Book and Candidate.
-   **Co-occurrence**: Boolean (1 if Candidate Author == Last Read Author).

## 5. Final Prediction
The final score is a weighted average of the rank-normalized predictions from CatBoost, XGBoost, and LightGBM. The weights are optimized on the Out-Of-Fold (OOF) predictions to maximize MAP@10.
